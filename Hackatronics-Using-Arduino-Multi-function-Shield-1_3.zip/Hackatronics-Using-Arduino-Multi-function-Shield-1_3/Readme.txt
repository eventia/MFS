An ebook containing these projects can be downloaded from:

https://files.cohesivecomputing.co.uk/Hackatronics-Arduino-Multi-function-Shield.pdf

Please note that the above link is the only authoritative source for this ebook. It is recommended that you do not download from other sources (e.g. mpja.com), as that version is likely to be out of date.

To ensure you have the latest version of the library and project source code, visit:

https://www.cohesivecomputing.co.uk/hackatronics/arduino-multi-function-shield/

Thank you